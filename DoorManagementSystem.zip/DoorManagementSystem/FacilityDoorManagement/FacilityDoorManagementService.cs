﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.ServiceModel;

namespace FacilityDoorManagement
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class FacilityDoorManagementService : IDoorManagementService
    {

        Object lockObj = new object();
        DBHelper dBHelper;
        public FacilityDoorManagementService()
        {
            dBHelper = new DBHelper();
        }
        public void AddNewDoor(Door newDoor)
        {
            try
            {
                if (newDoor != null)
                {
                    dBHelper.InsertNewDoor(newDoor);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Door> GetListOfAvailableDoors()
        {
            try
            {
                return dBHelper.GetAllDoors();
            }
            catch (Exception)
            {
                throw;
            }
        }


        public void RemoveDoor(int doorID)
        {
            dBHelper.DeleteDoor(doorID);
        }

        public void SaveModificationsToDoors(List<Door> modifiedDoors)
        {
            try
            {
                foreach (var item in modifiedDoors)
                {
                    dBHelper.UpdateExistingDoorOrAddNew(item);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
