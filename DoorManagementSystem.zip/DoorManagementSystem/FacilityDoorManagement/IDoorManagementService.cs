﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace FacilityDoorManagement
{
    // NOTE : Have made this as session mode so that single instance is created and maintained JUST for DEMO. We can remove once have real Database in place which will preserve data
    [ServiceContract(SessionMode = SessionMode.Required)]
    public interface IDoorManagementService
    {
        [OperationContract]
        void AddNewDoor(Door newDoor);
        [OperationContract]
        void RemoveDoor(int doorID);

        [OperationContract]
        List<Door> GetListOfAvailableDoors();

        [OperationContract]
        void SaveModificationsToDoors(List<Door> modifiedDoors);

    }
}
