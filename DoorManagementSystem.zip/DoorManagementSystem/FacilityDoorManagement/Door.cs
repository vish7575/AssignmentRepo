﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace FacilityDoorManagement
{
    [DataContract]
    public class Door
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        [Key]
        [Column(Order = 1)]
        [DataMember]
        public int DoorID { get; set; }

        [DataMember]
        public string DoorName { get; set; }

        [DataMember]
        public string FacilityID { get; set; }

        [DataMember]
        public string ClientID { get; set; }

        [DataMember]
        public string ClientName { get; set; }

        [DataMember]
        public string CustomLable { get; set; }

        [DataMember]
        public bool IsOpen { get; set; }

        [DataMember]
        public bool IsLocked { get; set; }

        [DataMember]
        public string DoorType { get; set; }
    }

    //NOTE: We shall restric who can add/remove, view the doors based on the access permissions
    public enum UserType
    {
        GeneralUser = 0,
        SecurityIncharge,
        SecurityHead
    }
}