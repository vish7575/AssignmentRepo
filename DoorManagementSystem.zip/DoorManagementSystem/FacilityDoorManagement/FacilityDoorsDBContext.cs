﻿using FacilityDoorManagement;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FacilityDoorManagement
{
    class FacilityDoorsDBContext : DbContext
    {
        public FacilityDoorsDBContext()
          : base(ConfigurationManager.ConnectionStrings["SqlCompactConnection"].ToString())
        {
        }

        public DbSet<Door> doorDataSet { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
