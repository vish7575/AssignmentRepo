﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace FacilityDoorManagement
{
    public class DBHelper
    {
        /// <summary>
        /// DBHelper class takes the responsibility of Database queries using entityFramework
        /// </summary>
        public DBHelper()
        {
            try
            {
                InitilizeDataBase();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void InitilizeDataBase()
        {
            try
            {
                using (var context = new FacilityDoorsDBContext())
                {
                    var s = context.Database.Connection;
                    context.Database.CreateIfNotExists();
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        internal void InsertNewDoor(Door newDoor)
        {
            try
            {
                using (var context = new FacilityDoorsDBContext())
                {
                    context.Database.Connection.Open();
                    context.Entry(newDoor).State = EntityState.Added;
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        internal void DeleteDoor(int doorID)
        {
            try
            {
                using (var context = new FacilityDoorsDBContext())
                {
                    context.Database.Connection.Open();
                    var query = context.doorDataSet.Where(x => x.DoorID == doorID).FirstOrDefault();
                    if (query!=null)
                    {
                        context.Entry(query).State = EntityState.Deleted;
                        context.SaveChanges();
                    }
                    else
                    {
                        throw new Exception("No such door found with ID:" + doorID.ToString() );
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        internal List<Door> GetAllDoors()
        {
            try
            {
                using (var context = new FacilityDoorsDBContext())
                {
                    context.Database.Connection.Open();

                    return context.doorDataSet.ToList(); ;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        internal void UpdateExistingDoorOrAddNew(Door doorObj)
        {
            try
            {
                using (var context = new FacilityDoorsDBContext())
                {
                    context.Database.Connection.Open();
                    var query = context.doorDataSet.Where(x=>x.DoorID== doorObj.DoorID).FirstOrDefault();
                    if (query != null)
                    {
                        query.IsLocked = doorObj.IsLocked;
                        query.IsOpen = doorObj.IsOpen;
                        query.CustomLable = doorObj.CustomLable;
                        query.ClientName = doorObj.ClientName;
                        query.DoorName = doorObj.DoorName;
                        query.DoorType = doorObj.DoorType;
                        context.Entry(query).State = EntityState.Modified;
                        context.SaveChanges();
                    }

                    else
                    {
                        context.Entry(doorObj).State = EntityState.Added;
                        context.SaveChanges();
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
